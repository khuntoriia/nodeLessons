module.exports = require('./').should();
